/** 
 * Classe para modelar um user
*/
export default class User {
    constructor(user, password){
        this.user = user
        this.password = password
    }
}